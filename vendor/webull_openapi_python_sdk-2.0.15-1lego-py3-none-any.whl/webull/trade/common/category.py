# Copyright 2022 Webull
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# 	http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# coding=utf-8

from webull.core.common.easy_enum import EasyEnum


class Category(EasyEnum):
    US_STOCK = (1, 'US STOCK')
    US_OPTION = (2, 'US OPTION')
    HK_STOCK = (3, 'HK STOCK')
    US_ETF = (5, 'US ETF')
    HK_ETF = (6, 'HK ETF')
    CN_STOCK = (7, "CN STOCK")
    US_CRYPTO = (8, "US CRYPTO")
    US_FUTURES = (12, "US FUTURES")
    HK_FUTURES = (13, "HK FUTURES")
