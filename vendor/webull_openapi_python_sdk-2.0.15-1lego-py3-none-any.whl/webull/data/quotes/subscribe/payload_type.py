# Copyright 2022 Webull
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# 	http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# coding=utf-8

PAYLOAD_TYPE_QUOTE = 'quote'
PAYLOAD_TYPE_SHAPSHOT = 'snapshot'
PAYLOAD_TYPE_TICK = 'tick'
PAYLOAD_TYPE_EVENT_DEPTH = 'event-quote'
PAYLOAD_TYPE_EVENT_SHAPSHOT = 'event-snapshot'
PAYLOAD_TYPE_EVENT_TICK = 'event-tick'